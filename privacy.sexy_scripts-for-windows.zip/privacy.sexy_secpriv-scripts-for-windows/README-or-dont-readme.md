 /$$$$$$$  /$$$$$$$$  /$$$$$$  /$$$$$$$  /$$      /$$ /$$$$$$$$                         /$$
| $$__  $$| $$_____/ /$$__  $$| $$__  $$| $$$    /$$$| $$_____/                        | $$
| $$  \ $$| $$      | $$  \ $$| $$  \ $$| $$$$  /$$$$| $$           /$$$$$$/$$$$   /$$$$$$$
| $$$$$$$/| $$$$$   | $$$$$$$$| $$  | $$| $$ $$/$$ $$| $$$$$       | $$_  $$_  $$ /$$__  $$
| $$__  $$| $$__/   | $$__  $$| $$  | $$| $$  $$$| $$| $$__/       | $$ \ $$ \ $$| $$  | $$
| $$  \ $$| $$      | $$  | $$| $$  | $$| $$\  $ | $$| $$          | $$ | $$ | $$| $$  | $$
| $$  | $$| $$$$$$$$| $$  | $$| $$$$$$$/| $$ \/  | $$| $$$$$$$$ /$$| $$ | $$ | $$|  $$$$$$$
|__/  |__/|________/|__/  |__/|_______/ |__/     |__/|________/|__/|__/ |__/ |__/ \_______/


(Brought to you by Shane Maloney of https://zypl.tk)

A collection of all the scripts that can be found at https://privacy.sexy in a cute zip file! =/)

I DO NOT claim ownership nor have ANY rights to ANY of these. DO NOT attempt to contact me. Fuck you




Yes that's all.

Andddd fuck you, again.



(fake copyright claim from a random year for an unregistered limited liability corporation --faggot)